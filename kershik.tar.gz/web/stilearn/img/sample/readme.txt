this image use for gallery.html
remove this if you want.