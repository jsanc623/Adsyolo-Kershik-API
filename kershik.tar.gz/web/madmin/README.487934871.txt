The _assets directory contains a Firewoks .PNG and two Photoshop .PSDs for the theme designs (you will most likely never need them, as the theme is CSS only).

The _tools directory contains the LESS CSS processor, in case you tweak the .less style files. These directories do not need to be on the server (unless you use uncompiled LESS styling on your live website - bad idea since Internet Explorer chokes on the LESS Javascript library...).

For support you can contact me at itconsulting@neuronq.ro.

Please start the email subject line with:
MADMIN - theme support - number_before_dot_txt_in_this_readme_file_s_name

Good luck with you Web-App and with your Start-Up! ;)