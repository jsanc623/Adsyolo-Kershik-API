<?php
// DSN, Database Name, Username, Password
$_ENV['dsn.mysql'] = array('mysql:host=localhost;dbname=recess', 'recess', 'recess', 'recess');
$_ENV['dsn.sqlite'] = array('sqlite::memory:','','','');
?>