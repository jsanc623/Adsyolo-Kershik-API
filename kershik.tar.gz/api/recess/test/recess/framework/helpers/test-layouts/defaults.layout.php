<?php
Layout::input($default, 'string', 'great success');
echo $default;
?>