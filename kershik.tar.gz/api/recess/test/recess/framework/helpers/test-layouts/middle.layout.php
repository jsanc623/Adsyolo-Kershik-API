<?php
Layout::extend('middle.master');
Layout::input($string, 'string');
$string .= ' middle';
$number = 2;
?>