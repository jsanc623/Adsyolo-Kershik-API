<?php
Layout::extend('middle');
$string = 'child';
?>