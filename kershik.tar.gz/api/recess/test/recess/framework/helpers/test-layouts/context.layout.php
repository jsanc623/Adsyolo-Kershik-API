<?php
Layout::input($context, 'string');
echo $context;
?>