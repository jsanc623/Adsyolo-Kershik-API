<?php
Layout::extend('defaults');
?>