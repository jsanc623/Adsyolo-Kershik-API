<?php
Layout::extend('multiple');

$int = 1;
$string = 'foo';

class ReallyObnoxiousClass { }
$object = new ReallyObnoxiousClass();

?>