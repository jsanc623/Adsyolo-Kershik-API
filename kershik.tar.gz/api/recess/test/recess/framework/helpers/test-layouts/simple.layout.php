<?php
Layout::input($string, 'string');
echo $string;
?>