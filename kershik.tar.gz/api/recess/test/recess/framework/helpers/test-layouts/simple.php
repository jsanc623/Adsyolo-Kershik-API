<?php
Layout::extend('simple');
$string = 'simple';
?>