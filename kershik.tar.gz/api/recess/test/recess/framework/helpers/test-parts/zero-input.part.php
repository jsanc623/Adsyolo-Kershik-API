<?php
echo 'no input';
?>