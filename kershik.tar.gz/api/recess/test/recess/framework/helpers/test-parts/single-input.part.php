<?php
Part::input($one, 'string');
echo $one;
?>