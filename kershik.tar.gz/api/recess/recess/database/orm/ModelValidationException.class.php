<?php

class ModelValidationException extends RecessException {
	
	
	
}

?>