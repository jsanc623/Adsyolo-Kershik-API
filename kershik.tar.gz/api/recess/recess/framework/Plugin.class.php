<?php
abstract class Plugin {
	
	abstract function init(Application $app);
	
}
?>