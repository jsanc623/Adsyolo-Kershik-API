<?php
/**
 * This class is provided for backwards compatibility with
 * any generated files in the edge-pre 0.2 release
 * 
 * @Todo: Delete this file with 0.3 release
 */
class RecessView extends LayoutsView {}
?>