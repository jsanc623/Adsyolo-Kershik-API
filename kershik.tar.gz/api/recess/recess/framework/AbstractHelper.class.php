<?php
abstract class AbstractHelper {
	public static function init(AbstractView $view) {}
}
?>