<?php

class RoutingResult {
	public $route = null;
	public $arguments = array();
	public $routeExists = false;
	public $methodIsSupported = false;
	public $acceptableMethods = array();
}

?>