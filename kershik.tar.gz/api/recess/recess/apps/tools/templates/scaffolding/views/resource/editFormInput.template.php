		<p>
			<label for="<?php echo $form->{{fieldName}}->getName(); ?>">{{fieldNameEnglish}}</label><br />
			<?php $form->input('{{fieldName}}'); ?>
		</p>
