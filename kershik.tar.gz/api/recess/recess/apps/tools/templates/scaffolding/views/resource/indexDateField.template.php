		<strong>{{fieldNameEnglish}}</strong>: <?php echo date(DATE_ISO8601,${{modelNameLower}}->{{fieldName}}); ?><br />
