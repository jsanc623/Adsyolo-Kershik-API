<ul>
	<li><?php echo Html::anchor(Url::action('{{programmaticName}}HomeController::index'), 'Home') ?></li>
	<!-- 
	Add your application's navigation links here.
	-->
</ul>