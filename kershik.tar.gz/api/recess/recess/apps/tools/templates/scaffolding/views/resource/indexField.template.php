		<strong>{{fieldNameEnglish}}</strong>: <?php echo ${{modelNameLower}}->{{fieldName}}; ?><br />
