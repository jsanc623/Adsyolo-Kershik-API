AdsYolo-Kershik-API
===================

This repository contains the source code for the AdsYolo 'Kershik' RESTful API.

#Requirements
1. This application requires a MySQL Database
2. This application is designed to run on Nginx web server

